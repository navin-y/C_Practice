#include<stdio.h>

int main(){
    int r,c,sum=0;
    printf("Enter the row and column:");
    scanf("%d %d",&r,&c);
    int arr[r][c];
    if(r!=c)
        printf("Given matrix is not a sq. matrix");
    else{
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++)
                scanf("%d",&arr[i][j]);
        }
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++)
                printf("%d ",arr[i][j]);
            printf("\n");
        }
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                if(i==j){
                    sum+=arr[i][j];
                }
            }
        }
        printf("Sum=%d",sum);
    }
}