#include<stdio.h>

int main(){
    int c=0;
    int arr[]={1,2,3,4,5};
    printf("Using Sizeof: %ld\n",sizeof(arr)/sizeof(arr[0]));
    for(int i=0;arr[i]!='\0';i++){
        c++;
    }
    printf("Using loop: %d\n",c);
}