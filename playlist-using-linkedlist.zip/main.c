#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Node{
    char name[100];
    struct Node *prev;
    struct Node *next;
};
struct Node *head=NULL;
struct Node *tail=NULL;

void addToPlaylist(char name[]){
    struct Node *newNode=(struct Node *)malloc(sizeof(struct Node));
    strcpy(newNode->name,name);
    newNode->prev=NULL;
    newNode->next=head;
    if(head!=NULL)
        head->prev=newNode;
    else
        tail=newNode;
    head=newNode;
}

void deleteAtPos(int pos){
    struct Node *temp=head;
    for(int i=1;i<pos-1;i++){//1
        temp=temp->next;
    }
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;
    free(temp);
}

void display(){
    struct Node *temp=head;
    while(temp!=NULL){
        printf("%s\n",temp->name);
        temp=temp->next;
    }
    printf("\n");
}

int main(){
    addToPlaylist("Kannana kanne");
    addToPlaylist("Indru netru naalai");
    addToPlaylist("Nee kavithaigala");
    display();
    deleteAtPos(3);
    display();
}