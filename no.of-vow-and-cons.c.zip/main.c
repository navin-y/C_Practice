#include <stdio.h>
#include<string.h>

int main()
{
    char *name;
    scanf("%s",name);
    int len=strlen(name);
    int n=0;
    for(int i=0;i<len;i++){
        if(strchr("aeiouAEIOU",name[i]))
            n++;
    }
    printf("%d,%d",n,len-n);

    return 0;
}
