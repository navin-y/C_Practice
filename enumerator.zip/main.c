#include<stdio.h>

enum data {a,b,c=10,d=4.5};

int main(){
    printf("%d %d %d %d",a,b,c,d);
}