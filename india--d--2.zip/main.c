#include<stdio.h>
#include<string.h>

int main(){
    char str[100],ch;
    fgets(str,100,stdin);
    printf("Enter the char: ");
    scanf("%c",&ch);
    int n=strlen(str);
    for(int i=0;i<n;i++){
        if(str[i]==ch)
            printf("%d ",i);
    }
}