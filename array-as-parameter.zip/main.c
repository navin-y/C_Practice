#include<stdio.h>

void func(int *arr,int len){
    for(int i=0;i<len;i++)
        printf("%d ",*(arr+i));
}

int main(){
    int arr[]={10,20,30,40,50};
    int len=sizeof(arr)/sizeof(arr[0]);
    func(&arr[0],len);
    return 0;
}