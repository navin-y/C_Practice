/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    while(1){
    int n,prev=0,curr=1,next;
    printf("Enter n:");
    scanf("%d",&n);
    printf("%d %d ",prev,curr);
    for(int i=2;i<n;i++){
        next=prev+curr;
        printf("%d ",next);
        prev=curr;
        curr=next;
    }
    printf("\n");
    }
    return 0;
}
