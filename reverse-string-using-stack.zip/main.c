#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Node{
    char c;
    struct Node *prev;
    struct Node *next;
};
struct Node *head=NULL;
struct Node *tail=NULL;

void push(char c){
    struct Node *newNode=(struct Node *)malloc(sizeof(struct Node));
    newNode->c=c;
    newNode->prev=NULL;
    newNode->next=head;
    if(head!=NULL)
        head->prev=newNode;
    else
        tail=newNode;
    head=newNode;
}

void display(){
    struct Node *temp=head;
    while(temp!=NULL){
        printf("%c",temp->c);
        temp=temp->next;
    }
    printf("\n");
}

void reverseString(){
    struct Node *temp1=head;
    struct Node *temp2=tail;
    char t;
    while(temp1!=temp2 && temp1!=temp2->prev){
        t=temp1->c;
        temp1->c=temp2->c;
        temp2->c=t;
        temp1=temp1->next;
        temp2=temp2->prev;
    }
}

int main(){
    char str[100];
    printf("Enter the string:");
    scanf("%s",str);
    int n=strlen(str);
    for(int i=n-1;i>=0;i--)
        push(str[i]);
    display();
    reverseString();reverseString();
    display();
}