#include<stdio.h>

int main(){
    int n,c=1;
    scanf("%d",&n);
    for(int i=100;;i++){
        if(c<=n){
            int ch=0;
            for(int j=2;j<=i/2;j++){
                if(i%j==0)
                    ch++;
            }
            if(ch==0){
                printf("%d ",i);
                c++;
            }
        }
        else
            break;
    }
}

