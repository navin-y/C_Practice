#include<stdio.h>

struct paySlip{
  int id;
  char name[100];
  int bSal;
  int hra;
  int da;
  int medAllow;
  int pf;
  int insur;
};

int main()
{
    int n,s;
    printf("Enter the number of employees: ");
    scanf("%d",&n);
    struct paySlip e[n];
    printf("Enter your input for every employee:\n");
    for(int i=0;i<n;i++){
      printf("Employee ID: ");
      scanf("%d",&e[i].id);
      printf("Employee Name: ");
      scanf("%s",e[i].name);
      printf("Basic Salary, HRA: ");
      scanf("%d %d",&e[i].bSal,&e[i].hra);
      printf("DA, Medical Allowance: ");
      scanf("%d %d",&e[i].da,&e[i].medAllow);
      printf("PF and Insurance: ");
      scanf("%d %d",&e[i].pf,&e[i].insur);
      printf("\n");
    }
    printf("Enter employee ID to get payslip: ");
    scanf("%d",&s);
    for(int i=0;i<n;i++){
      if(e[i].id==s){
        printf("Salary Slip of %s:\n",e[i].name);
        printf("Employee ID: %d\n",e[i].id);
        printf("Basic Salary: %.2f\n",(float)e[i].bSal);
        printf("House Rent Allowance: %.2f\n",(float)e[i].hra);
        printf("Dearness Allowance: %.2f\n",(float)e[i].da);
        printf("Medical Allowance: %.2f\n",(float)e[i].medAllow);
        printf("Gross Salary: %.2f Rupees\n\n",(float)(e[i].bSal+e[i].hra+e[i].da+e[i].medAllow));
        printf("Deductions:\nProvident fund: %.2f\n",(float)e[i].pf);
        printf("Insurance: %.2f\nNet Salary: %.2f Rupees",(float)e[i].insur,(float)(e[i].bSal+e[i].hra+e[i].da+e[i].medAllow)-(e[i].pf+e[i].insur));
        
      }
    }
    return 0;
}