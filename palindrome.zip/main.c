#include <stdio.h>
#include<string.h>

int main(){
    char str[100];
    scanf("%s",str);
    int n=strlen(str);

    int c=0,j=n-1;
    for(int i=0;i<n;i++){
        if(str[i]==str[j]){
            c++;
        }
        j--;
    }   
    if(c==n)
        printf("Palindrome");
    else
        printf("Not Palindrome");
}