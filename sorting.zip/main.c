#include<stdio.h>

void merge(int* nums1, int nums1Size, int m, int* nums2, int nums2Size, int n) {
    int j=0;
    for(int i=0;i<m+n;i++){
        if(nums1[i]==0){
            nums1[i]=nums2[j];
            j++;
        }
    }
    for(int i=0;i<m+n-1;i++){
        for(int j=1;j<m+n;j++){
            if(nums1[j]<nums1[i]){
                int t=nums1[i];
                nums1[i]=nums1[j];
                nums1[j]=t;
            }
        }
    }
    for(int i=0;i<m+n;i++)
        printf("%d ",nums1[i]);
}

int main(){
    int num1[]={1,2,3,0,0,0};
    int num2[]={2,5,6};
    merge(num1,6,3,num2,3,3);
}