#include<stdio.h>
#include<math.h>

int main(){
    int n,d=0,p,temp,sum=0;
    scanf("%d",&n);
    temp=n;
    while(temp>0){
        temp/=10;
        d++;
    }
    temp=n;
    while(n>0){
        p=pow(n%10,d);
        sum=sum+p;
        n/=10;
    }
    if(temp==sum)
        printf("Armstrong");
    else
        printf("Not Armstrong");
}