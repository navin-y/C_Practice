#include <stdio.h>
#include<string.h>

int main()
{
    char str[100];
    scanf("%s",str);
    int n=strlen(str);
    int sum=0;
    for(int i=0;i<n;i++){
        if(str[i]>='0' && str[i]<='9'){
            sum+=(int)str[i]-48;
        }
    }
    printf("%d",sum);

    return 0;
}
