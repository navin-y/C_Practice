#include<stdio.h>

int main(){
    int a,b;
    int ch=1;
    while(ch==1){
        printf("Enter a numbers to be added\n");
        scanf("%d %d",&a,&b);
        printf("Sum: %d\n",a+b);
        printf("Press 1 to continue, Press 0 to exit\n");
        scanf("%d",&ch);
        if(ch>1){
            printf("invalid input!\n");
            break;
        }
    }
}