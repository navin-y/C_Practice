#include<stdio.h>
#include <unistd.h>

int main(){
    
    int n,m,s,i,j,k;
    char c1,c2;
    printf("Enter the time in format (hr:min:): ");
    scanf("%d %c %d %c %d",&n,&c1,&m,&c2,&s);
    i=n;
    j=m;
    k=s;
    for(;i<=12;i++){
        for(;j<60;j++){
            for(;k<60;k++){
                printf("%2.2d : %2.2d : %2.2d\n",i,j,k);
                sleep(1);
                if(k==59){
                    k=0;
                }
            }
            if(j==59){
                j=0;
            }
        }
        if(i==12){
            i=0;
        }
    }
}