/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,ec=0,oc=0;
    scanf("%d",&size);
    int arr[size];
    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
        if(arr[i]%2==0)
            ec++;
        else
            oc++;
    }
    int evenarr[ec], oddarr[oc],ei=0,oi=0;
    for(int j=0;j<size;j++){
        if(arr[j]%2==0){
            evenarr[ei]=arr[j];
            ei++;
        }
        else{
            oddarr[oi]=arr[j];
            oi++;
        }
    }
    printf("Even array\n");
    for(int k=0;k<ei;k++){
        printf("%d ",evenarr[k]);
    }
    printf("\nOdd array\n");
    for(int l=0;l<oi;l++){
        printf("%d ",oddarr[l]);
    }
    
    return 0;
}