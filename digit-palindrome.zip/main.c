#include<stdio.h>

int main(){
    int n,res=0,temp;
    scanf("%d",&n);
    temp=n;
    while(n>0){
        res=res*10+(n%10);
        n/=10;
    }
    if(res==temp){
       printf("Palindrome");
    }
    else{
        printf("Not a Palindrome");
    }
}