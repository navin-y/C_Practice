#include<stdio.h>
 //call by reference
 
 void func(int *a,int *b){
    int c;
    *a=*a+10;
    *b=*b+10;
    c=*a+*b;
    printf("%d\n",c);
 }
 
 int main(){
    int a=10,b=5;
    func(&a,&b);
    printf("%d",a*b);
 }