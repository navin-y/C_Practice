/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int amt;//1100
    scanf("%d",&amt);
    
    if(amt%100>50 && amt%100<99){
        printf("Invalid Amount Entered!");
    }
    else{
    int c500=amt/500;//2
    amt%=500;//100
    int c200=amt/200;//0
    amt%=200;//100
    int c100=amt/100;//1
    amt%=100;//0
    int c50=amt/50;//0
    amt%=50;//0
    
    if(c500){
        printf("500 x %d\n",c500);
    }
    if(c200){
        printf("200 x %d\n",c200);
    }
    if(c100){
        printf("100 x %d\n",c100);
    }
    if(c50){
        printf("50 x %d\n",c50);
    }
    }
    
    return 0;
}