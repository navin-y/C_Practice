#include<stdio.h>
#include<string.h>

int main(){
    char in[100];
    char out1[100];
    char out2[100];
    scanf("%s",in);
    int len=strlen(in);
    int j=0,c=0;
    for(int i=0;i<len;i++){
        if(in[i]!='x' && in[i]!='X'){
            out1[j]=in[i];
            j++;
        }
        else{
            out2[c]=in[i];
            c++;
        }
    }
    strcat(out1,out2);
    printf("%s",out1);
}