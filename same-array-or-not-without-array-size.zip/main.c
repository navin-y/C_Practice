#include<stdio.h>

int main(){
    //int a=1;b=1;
    int arr1[100];
    int n2=0,d;
    printf("Enter the array 1 elements:\n");
    for(int i=0;;i++){
        scanf("%d",&d);
        if(d<0)
            break;
        else{
            arr1[i]=d;
            n2++;
        }
    }
    int arr2[n2];
    printf("Enter the array 2 elements:\n");
    for(int i=0;i<n2;i++){
        scanf("%d",&arr2[i]);
    }
    int c=0;
    for(int i=0;i<n2;i++){
        if(arr1[i]!=arr2[i])
            c++;
    }
    if(c==0)
        printf("Same Array");
    else
        printf("Not Same array");
}