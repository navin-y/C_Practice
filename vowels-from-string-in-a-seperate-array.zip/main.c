#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main(){
    char str[100];
    scanf("%s",str);
    int n=strlen(str);
    char arr[n];
    int j=0;
    
    for(int i=0;i<n;i++){
        if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u' || str[i]=='A'|| str[i]=='E'|| str[i]=='I' || str[i]=='O' || str[i]=='U'){
            arr[j]=str[i];
            j++;
        }
    }
    arr[j]='\0';
    printf("%s\n",arr);
    for(int i=0;i<j;i++){
        printf("%c",arr[i]);
    }
}