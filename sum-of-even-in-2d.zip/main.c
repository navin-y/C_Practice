#include<stdio.h>

int main(){
    int r,c;
    printf("Enter the rows and column:");
    scanf("%d %d",&r,&c);
    printf("Enter the values:\n");
    int arr[i][j];
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++)
            scanf("%d",&arr[i][j]);
    }
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++)
            printf("%d ",arr[i][j]);
        printf("\n");
    }
    z
    
}