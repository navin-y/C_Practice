#include <stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    char *name;
    scanf("%s",name);
    int len=strlen(name);
    char *res;
    int k=0;
    for(int i=0;i<len;i++){
        for(int j=0;j<=i;j++){
            sprintf(res + strlen(res),"%c",name[i]);
        }
    }
    printf("%s",res);
    return 0;
}
