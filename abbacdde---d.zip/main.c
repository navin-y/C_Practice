#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(){
    char str[100];
    scanf("%s",str);
    int len=strlen(str);
    int c,a=0;
    for(int i=0;i<len-1;i++){
        c=0;
        for(int j=i+1;j<len;j++){
            if(str[i]==str[j] && str[i]!='0'){
                c++;
                str[j]='0';
            }
        }
        printf("%s\n",str);
        if(c==0){
            printf("%c\n%c",str[i+1],str[i+1]+1);
            break;
        }
    }
}



