#include <stdlib.h>
#include<string.h>

// in both functions, return heap-allocated strings:

char *encode(const char *s) {
  int l=strlen(s);
  char *op=(char *)malloc(l*sizeof(char));
    for(int i=0;i<l;i++){
      if(s[i]=='a')
          op[i]='1';
      else if(s[i]=='e')
          op[i]='2';
      else if(s[i]=='i')
          op[i]='3';
      else if(s[i]=='o')
          op[i]='4';
      else if(s[i]=='u')
          op[i]='5';
      else
        op[i]=s[i];
    }
  op[l]='\0';
    return op;
  free(op);
}

char *decode(const char *s) {
  int l=strlen(s);
  char *op=(char *)malloc(l*sizeof(char));
    for(int i=0;i<l;i++){
    if(s[i]=='1')
          op[i]='a';
      else if(s[i]=='2')
          op[i]='e';
      else if(s[i]=='3')
          op[i]='i';
      else if(s[i]=='4')
          op[i]='o';
      else if(s[i]=='5')
          op[i]='u';
      else
        op[i]=s[i];
    }
  op[l]='\0';
    return op;
  free(op);
}


int main(){
    char *op=encode("hi iam c");
    printf("%s",op);
}